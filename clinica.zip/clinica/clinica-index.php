<?php include 'header.php'; ?> <!--NOS PERMITE DESPLEGAR EL NAV BAR SIN REPETIR EL MISMO CODIGO EN CADA ARCHIVO-->
<?php include('connect.php'); ?> <!--NOS PERMITE HACER LA CONEXION A LA BASE DE DATOS SIN REPETIR EL MISMO CODIGO EN CADA ARCHIVO-->
<!DOCTYPE html>
<html lang="es">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <<link rel="shortcut icon" href="medicina.jpg"/>
</head>
   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
   <script type="text/javascript"> //SCRIPT QUE NOS PERMITE UTILIZAR LAS API DE GOOGLE CHARTS PARA DESPLEGAR LA GRAFICA
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
         var data = google.visualization.arrayToDataTable([
         ['class Name','Medicos'],
         <?php
         $resultado = $connect->query("SELECT especialidad, count(*) as total FROM medico GROUP BY especialidad");

         while($fila = mysqli_fetch_array($resultado)) {
            echo "['".$fila['especialidad']."',".$fila['total']."],";
         }
         ?>
         ]);

        var options = {
          title: 'WD-CLinica'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
        chart.draw(data, options);
      }
   </script>
   <body>
   <img src="medicina.jpg" class="imgLogo" alt="WD-Clinica"><br><br>

   <br><div class="w3-content w3-display-container">
      <img class="mySlides w3-animate-fading" src="img/banner01.jpg" style="width:100%">
      <img class="mySlides w3-animate-fading" src="img/banner02.jpg" style="width:100%">
      <img class="mySlides w3-animate-fading" src="img/banner03.jpg" style="width:100%">
   </div>
   <p>
   Somos el Centro de Salud con más de 16 años de experiencia, 
   contamos con la mejor y moderna infraestructura de la ciudad de Loja, 
   también con el personal médico mejor capacitado de toda la región.

   Nuestro principal objetivo es brindar salud de manera profesional y accesible al alcance de los habitantes de la zonas australes del Ecuador. 
  </p>
   <div id="piechart" style="width: 700px; height: 300px;"></div>
   
   <p class="text01">
      Comprometidos con tu salud.
   </p>

   <p class="text02">
      Nuestra clínica está enfocada en ofrecer los servicios con los estándares de calidad más alto, porque lo más importante es tu salud, contamos con diversos servicios para tu tranquilidad, así como médicos especialistas en diversas ramas.
   </p><br>

   <script> //SCRIPT QUE NOS PERMITE HACER EL SLIDER DE IMAGENES AUTOMATICO
   var slideIndex = 0;
   carousel();

   function carousel() {
      var i;
      var x = document.getElementsByClassName("mySlides");
      for (i = 0; i < x.length; i++) {
         x[i].style.display = "none";
      }
      slideIndex++;
      if (slideIndex > x.length) {slideIndex = 1}
         x[slideIndex-1].style.display = "block";
         setTimeout(carousel, 6000); // CAMBIA LA IMAGEN CADA 8 SEGUNDOS
   }
   </script>

   
<footer>
      
      <!--Redes sociales-->
      <div class="rs">
            <!--Hipervinculo que nos lleva a la página oficial de facebook-->
            <br>
            <br>
            <a href="https://www.facebook.com/">
                <img src="Redes Sociales/facebook.png" style="width:30px;height:30px;">
            </a>
            <!--Hipervinculo que nos lleva a la página oficial de Instagram-->
            <a href="https://www.instagram.com/">
                <img src="Redes Sociales/instagram.png" style="width:30px;height:30px;">
            </a>
            <!--Hipervinculo que nos lleva a la página oficial de twitter-->
            <a href="https://twitter.com/?lang=es">
                <img src="Redes Sociales/twitter.png" style="width:30px;height:30px;">
            </a>
            <!--Hipervinculo que nos lleva a la página oficial de You tube-->
            <a href="https://www.youtube.com/">
                <img src="Redes Sociales/youtube.png" style="width:33px;height:30px;">
            </a>
            <br>
            <br>
            <!---Licencia Creative Commons--->
            <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Licencia de Creative Commons" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br />Este obra está bajo una <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">licencia de Creative Commons Reconocimiento-NoComercial-CompartirIgual 4.0 Internacional</a>.
        </div>
    </footer>
   </body>
</html>