Swal.fire({
  icon: 'success',
  title: 'Agenda exitosa',
  text: 'Su cita fue registrada correctamente!',
  showConfirmButton: false,
  timer: 2500
})// MENSAJES DE ALERTA